Searchable Dictionary v2
========================

This is a port of the Android Searchable Dictionary v2 sample.

It demonstrates using Android's search framework.
